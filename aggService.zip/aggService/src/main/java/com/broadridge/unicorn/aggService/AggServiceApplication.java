package com.broadridge.unicorn.aggService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AggServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AggServiceApplication.class, args);
	}

}
