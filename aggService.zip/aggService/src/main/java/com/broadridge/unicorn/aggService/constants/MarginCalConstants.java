package com.broadridge.unicorn.aggService.constants;

import java.io.Serializable;

public class MarginCalConstants implements Serializable{
	
	

}
