package com.broadridge.unicorn.aggService.constants;

public class MarginCalSQLConstants { 
	
	public static final String MARGIN_CAL_SQL="";
	
}
