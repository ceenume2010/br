package com.broadridge.unicorn.aggService.constants;

import java.io.Serializable;

public class RestUriConstants implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1212221531121764773L;
	
	public static final String GET_MARGIN_CAL="getMargincalculation";

}
