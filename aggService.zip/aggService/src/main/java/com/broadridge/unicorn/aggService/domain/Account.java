package com.broadridge.unicorn.aggService.domain;

import java.io.Serializable;

public class Account implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5793244106310336271L;

}
