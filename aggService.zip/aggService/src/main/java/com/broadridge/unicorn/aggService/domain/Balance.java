package com.broadridge.unicorn.aggService.domain;

import java.io.Serializable;

public class Balance implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9043591844519153646L;

}
