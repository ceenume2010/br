package com.broadridge.unicorn.aggService.domain;

import java.io.Serializable;

public class BalanceDetail implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7712448482102386401L;

}
