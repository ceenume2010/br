package com.broadridge.unicorn.aggService.domain;

import java.io.Serializable;

public class Position implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 193809110122182468L;

}
