package com.broadridge.unicorn.aggService.domain;

import java.io.Serializable;

public class PositionDetail implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2070438615294510888L;

}
