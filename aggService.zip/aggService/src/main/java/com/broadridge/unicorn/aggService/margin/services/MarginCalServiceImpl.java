/**
 * 
 */
package com.broadridge.unicorn.aggService.margin.services;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.broadridge.unicorn.aggService.beans.MarginCalBean;
import com.broadridge.unicorn.aggService.beans.MarginCalRequestBean;
import com.broadridge.unicorn.aggService.beans.MarginCalResponseBean;

@Service("marginCalService")
public class MarginCalServiceImpl implements MarginCalService {

	private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());
	/**
	 * 
	 */
	private static final long serialVersionUID = 2370418826650610247L;

	@Override
	public List<MarginCalResponseBean> getMarginCaluculation(MarginCalRequestBean marginCalRequestBean)
			throws SQLException {
		List<MarginCalResponseBean> marginCalResponse= new ArrayList<>();
		try {
			Connection conn = DBClient.getConnection();
			conn.setAutoCommit(false);
			Statement stmt = conn.createStatement();
			String date = marginCalRequestBean.getDate();
			List<String> accountIds = marginCalRequestBean.getAccounts();
			accountIds.parallelStream().forEach(accountid->
			{
				try {
					double tradeDtBalance = getTradeDateBalance(conn, stmt, date,accountid);
					double marketValue=getMarkeValue(conn, stmt, date,accountid);
					double marketValuefromTrns= getMarkeValuefromTransaction( conn,  stmt, date , accountid);
					marginCalResponse.add(getMarginNumbers(accountid,tradeDtBalance,marketValue,marketValuefromTrns));
				} catch (SQLException e) {
					}
			}
			);
		} catch (Exception e) {
		}
		return marginCalResponse;
	}

	private MarginCalResponseBean getMarginNumbers(String accountId,double tradeDtBalance, double marketValue,double marketValuefromTrns)
	{
		LOGGER.info(String.format("*****************************************************************"));
		LOGGER.info(String.format("TradeDtBalance = [%s] MarketValue = [%s] ",tradeDtBalance,marketValue));		
		LOGGER.info(String.format("MarketValuefromTrns = [%s] ",marketValuefromTrns));
		MarginCalResponseBean marginCalResponse = new MarginCalResponseBean();
		MarginCalBean maginCal = new MarginCalBean();
		double equity=marketValue-tradeDtBalance;
		double regT=equity-(double)(50 * marketValuefromTrns)/100;
		double house=equity-(double)(30 * marketValue)/100;
		double maintenance=equity-(double)(25 * marketValue)/100;
		maginCal.setRegT(regT);
		maginCal.setHouse(house);		
		maginCal.setMaintenance(maintenance);
		// -- Buying power calc
		double maintenanceExcess=(double)maintenance/0.3;
		double regTexcess=regT *2;
		LOGGER.info(String.format("MaintenanceExcess = [%s] RegTexcess = [%s] ",maintenance,regT));	
		LOGGER.info(String.format("*****************************************************************"));
		double buyingPower = (maintenanceExcess >regTexcess) ? regTexcess : maintenanceExcess;
		maginCal.setBuyPower(buyingPower);
		//
		marginCalResponse.setAccountNo(accountId);
		marginCalResponse.setMargin(maginCal);
		return marginCalResponse;
	}
	
	private double getTradeDateBalance(Connection conn, Statement stmt,String date ,String accountId)
			throws SQLException {
		double tradeDtBalance = 0;
		String tradeDateBalanceSQL = "select TRUNC(bd.trade_date_balance,2) as trade_date_balance from balance b, balancedetail bd, account a  where b.balance_id=bd.balance_id and bd.balance_detail_date='"
				+ date + "' and a.\"AccountIdentifier\"='" + accountId + "' and a.\"AccountIdentifier\"=b.account_id;";
		ResultSet result = stmt.executeQuery(tradeDateBalanceSQL);
		while (result.next()) {
			tradeDtBalance = result.getDouble("trade_date_balance");
		}
		return tradeDtBalance;
	}
	
	
	private double getMarkeValue(Connection conn, Statement stmt,String date ,String accountId)	throws SQLException {
		double marketValue = 0;
		String marketValueSQL = "select TRUNC(SUM(pd.\"TradeDateQuantity\" * pr.price),2) as market_value from \"position\" p ,positiondetail pd, price pr where p.account_id='"+ accountId+"' and pd.position_detail_date='"+date+"' and pr.price_date='"+date+"' and p.position_id=pd.position_id and p.symbol=pr.symbol group by p.account_id;";
		ResultSet result = stmt.executeQuery(marketValueSQL);
		while (result.next()) {
			marketValue = result.getDouble("market_value");
		}
		return marketValue;
	}
		
	
	private double getMarkeValuefromTransaction(Connection conn, Statement stmt,String date ,String accountId)	throws SQLException {
		double marketValuefromTrns = 0;
		String marketValuefromTrnsSQL = "select TRUNC(SUM(quantity*price),2) as reqT_marketvalue from public.transaction_history where account='"+accountId+"'  and trade_dt<='"+date+"' group by account;";
		ResultSet result = stmt.executeQuery(marketValuefromTrnsSQL);
		while (result.next()) {
			marketValuefromTrns = result.getDouble("reqt_marketvalue");
		}
		return marketValuefromTrns;
	}
	
	private void validateMarginCalInput(MarginCalRequestBean marginCalRequestBean) {

	}
	


}
